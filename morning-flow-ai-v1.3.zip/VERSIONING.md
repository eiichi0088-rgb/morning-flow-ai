# MORNING FLOW AI Versioning Rules

1. 画面表示のバージョン番号とZIP保存のバージョン番号を一致させる。
2. ZIP名は `morning-flow-ai-vX.Y.zip` とする。
3. 新機能追加後は必ず `npm.cmd run build` を実行する。
4. ビルド成功後に同じバージョン番号でZIP保存する。
5. ZIPには `node_modules` と `.env` を含めない。
6. ZIPには `dist` を含める。
7. 開発完了時は `CHANGELOG.md` に変更内容を記録する。
8. 可能な限り `npm.cmd run release` で `build → zip → changelog` をまとめて実行する。
