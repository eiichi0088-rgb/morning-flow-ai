$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$packageJson = Get-Content -LiteralPath (Join-Path $root 'package.json') -Raw | ConvertFrom-Json
$version = ([string]$packageJson.version) -replace '\.0$', ''
$date = Get-Date -Format 'yyyy-MM-dd'
$path = Join-Path $root 'CHANGELOG.md'

if (!(Test-Path -LiteralPath $path)) {
  @'
# CHANGELOG

このファイルには MORNING FLOW AI の各バージョンの変更内容を記録します。

'@ | Set-Content -LiteralPath $path -Encoding UTF8
}

$content = Get-Content -LiteralPath $path -Raw
$heading = "## Version $version - $date"

if ($content -notmatch [regex]::Escape("## Version $version")) {
  $entry = @"
$heading

- OpenAI API による実入力のAI整理に対応
- AI処理を `src/services/aiPlanner.ts` に分離
- 仕事・健康・家族・学習の4カテゴリー分類を追加
- `.env` によるAPIキー管理を追加
- `morning-flow-ai-v$version.zip` として保存

"@

  $updated = $content.TrimEnd() + "`r`n`r`n" + $entry
  Set-Content -LiteralPath $path -Value $updated -Encoding UTF8
}

Write-Host "CHANGELOG_UPDATED: Version $version"
