$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$zipPath = Join-Path $root 'morning-flow-ai-v1.zip'

if (Test-Path -LiteralPath $zipPath) {
  Remove-Item -LiteralPath $zipPath -Force
}

$excludedNames = @(
  'node_modules',
  '.npm-cache',
  'morning-flow-ai-mvp.zip',
  'morning-flow-ai-v1.2.zip',
  'morning-flow-ai-v1.zip',
  'morning-flow-ai-v2.zip',
  'morning-flow-ai-v3.zip',
  'morning-flow-ai-v4.zip'
)

$items = Get-ChildItem -LiteralPath $root -Force |
  Where-Object { $excludedNames -notcontains $_.Name }

Compress-Archive -LiteralPath $items.FullName -DestinationPath $zipPath -Force
