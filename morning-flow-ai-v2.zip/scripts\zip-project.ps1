$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$zipPath = Join-Path $root 'morning-flow-ai-v2.zip'

if (Test-Path -LiteralPath $zipPath) {
  Remove-Item -LiteralPath $zipPath -Force
}

$excludedNames = @(
  'node_modules',
  '.npm-cache',
  '.env',
  'morning-flow-ai-mvp.zip',
  'morning-flow-ai-v1.2.zip'
)

$items = Get-ChildItem -LiteralPath $root -Force |
  Where-Object {
    $excludedNames -notcontains $_.Name -and
    $_.Name -notlike 'morning-flow-ai-v*.zip'
  }

Compress-Archive -LiteralPath $items.FullName -DestinationPath $zipPath -Force
