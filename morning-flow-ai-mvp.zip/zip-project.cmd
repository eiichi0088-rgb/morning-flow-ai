@echo off
chcp 65001 > nul
setlocal
cd /d "%~dp0"

echo MORNING FLOW AI のZIPを作成しています...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\zip-project.ps1"

echo.
if exist "%~dp0morning-flow-ai-mvp.zip" (
  echo ZIP作成完了
  echo 保存先: %~dp0morning-flow-ai-mvp.zip
) else (
  echo ZIP作成に失敗しました
)
echo.
pause
