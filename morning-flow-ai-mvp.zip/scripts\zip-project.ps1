$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$zipPath = Join-Path $root 'morning-flow-ai-mvp.zip'

if (Test-Path -LiteralPath $zipPath) {
  Remove-Item -LiteralPath $zipPath -Force
}

$excludedNames = @(
  'node_modules',
  '.npm-cache',
  'morning-flow-ai-mvp.zip'
)

$items = Get-ChildItem -LiteralPath $root -Force |
  Where-Object { $excludedNames -notcontains $_.Name }

Compress-Archive -LiteralPath $items.FullName -DestinationPath $zipPath -Force
