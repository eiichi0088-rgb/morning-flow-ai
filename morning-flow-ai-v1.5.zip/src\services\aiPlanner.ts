export type LifeCategory = 'work' | 'health' | 'family' | 'learning';

export interface MorningPlan {
  purpose: string;
  goals: string[];
  todos: string[];
  priorities: {
    highest: string[];
    important: string[];
    optional: string[];
  };
  schedule: {
    time: string;
    task: string;
  }[];
  advice: string[];
  categories: Record<LifeCategory, string[]>;
}

export async function createAiMorningPlan(transcript: string): Promise<MorningPlan> {
  const response = await fetch('/api/plan', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ transcript }),
  });

  const payload = await response.json().catch(() => null);

  if (!response.ok) {
    throw new Error(payload?.message ?? 'AI整理に失敗しました。設定を確認してください。');
  }

  return normalizePlan(payload.plan);
}

function normalizePlan(plan: MorningPlan): MorningPlan {
  return {
    purpose: plan.purpose || '今日を落ち着いて整える',
    goals: safeArray(plan.goals),
    todos: safeArray(plan.todos),
    priorities: {
      highest: safeArray(plan.priorities?.highest),
      important: safeArray(plan.priorities?.important),
      optional: safeArray(plan.priorities?.optional),
    },
    schedule: Array.isArray(plan.schedule)
      ? plan.schedule.map((item) => ({
          time: String(item.time ?? '時間調整'),
          task: String(item.task ?? '予定'),
        }))
      : [],
    advice: safeArray(plan.advice),
    categories: {
      work: safeArray(plan.categories?.work),
      health: safeArray(plan.categories?.health),
      family: safeArray(plan.categories?.family),
      learning: safeArray(plan.categories?.learning),
    },
  };
}

function safeArray(value: unknown): string[] {
  return Array.isArray(value) ? value.map(String).filter(Boolean) : [];
}
