import React from 'react';
import ReactDOM from 'react-dom/client';
import {
  ArrowRight,
  Brain,
  CalendarClock,
  CheckCircle2,
  Flag,
  Lightbulb,
  ListChecks,
  Mic,
  RefreshCw,
  Route,
  Sparkles,
  Square,
  Target,
} from 'lucide-react';
import './styles.css';

type SpeechRecognitionResultListLike = SpeechRecognitionResultList;

interface SpeechRecognitionEventLike extends Event {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultListLike;
}

interface SpeechRecognitionErrorEventLike extends Event {
  readonly error: string;
}

interface SpeechRecognitionLike extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onstart: (() => void) | null;
  onend: (() => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

interface MorningPlan {
  purpose: string;
  goals: string[];
  todos: string[];
  priorities: {
    highest: string[];
    important: string[];
    optional: string[];
  };
  schedule: {
    time: string;
    task: string;
  }[];
  advice: string[];
}

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  }
}

const SpeechRecognition =
  window.SpeechRecognition ?? window.webkitSpeechRecognition;

const sampleTranscript =
  '今日は朝9時から仕込みをして、11時から14時まで昼営業。売上目標を達成したい。15時に銀行で手続き、17時に買い物。家族との時間も取りたい。夜22時半にジムへ行って30分運動したい。銀行の営業時間に間に合うように注意したい。';

const knownTasks = [
  '仕込み',
  '昼営業',
  '営業',
  '銀行',
  '買い物',
  'ジム',
  '運動',
  '家族との時間',
  '会議',
  'メール返信',
  '資料作成',
  '掃除',
  '洗濯',
  '通院',
  '勉強',
  '読書',
  '散歩',
];

function App() {
  const [recognition, setRecognition] = React.useState<SpeechRecognitionLike | null>(null);
  const [isListening, setIsListening] = React.useState(false);
  const [transcript, setTranscript] = React.useState('');
  const [interimTranscript, setInterimTranscript] = React.useState('');
  const [error, setError] = React.useState('');
  const [plan, setPlan] = React.useState<MorningPlan | null>(null);
  const [isOrganizing, setIsOrganizing] = React.useState(false);

  const isSupported = Boolean(SpeechRecognition);
  const resultText = [transcript, interimTranscript].filter(Boolean).join('\n');
  const canOrganize = Boolean(transcript.trim()) && !isListening;

  React.useEffect(() => {
    if (!SpeechRecognition) return;

    const instance = new SpeechRecognition();
    instance.lang = 'ja-JP';
    instance.continuous = true;
    instance.interimResults = true;

    instance.onstart = () => {
      setIsListening(true);
      setError('');
    };

    instance.onend = () => {
      setIsListening(false);
      setInterimTranscript('');
    };

    instance.onerror = (event) => {
      setIsListening(false);
      setInterimTranscript('');
      setError(getSpeechErrorMessage(event.error));
    };

    instance.onresult = (event) => {
      let finalText = '';
      let interimText = '';

      for (let index = event.resultIndex; index < event.results.length; index += 1) {
        const phrase = event.results[index][0].transcript;
        if (event.results[index].isFinal) {
          finalText += phrase;
        } else {
          interimText += phrase;
        }
      }

      if (finalText) {
        setTranscript((current) => `${current}${current ? '\n' : ''}${finalText.trim()}`);
        setPlan(null);
      }
      setInterimTranscript(interimText.trim());
    };

    setRecognition(instance);

    return () => {
      instance.abort();
    };
  }, []);

  const startListening = () => {
    if (!recognition || isListening) return;

    setError('');
    try {
      recognition.start();
    } catch {
      setError('音声認識を開始できませんでした。少し待ってからもう一度お試しください。');
    }
  };

  const stopListening = () => {
    recognition?.stop();
  };

  const resetTranscript = () => {
    recognition?.abort();
    setTranscript('');
    setInterimTranscript('');
    setError('');
    setIsListening(false);
    setPlan(null);
  };

  const useSample = () => {
    recognition?.abort();
    setTranscript(sampleTranscript);
    setInterimTranscript('');
    setError('');
    setIsListening(false);
    setPlan(null);
  };

  const organizeMorning = () => {
    if (!transcript.trim()) return;

    setIsOrganizing(true);
    window.setTimeout(() => {
      setPlan(createMorningPlan(transcript));
      setIsOrganizing(false);
    }, 520);
  };

  return (
    <main className="app-shell">
      <div className="ambient-layer" aria-hidden="true">
        <span className="morning-orbit orbit-one" />
        <span className="morning-orbit orbit-two" />
        <span className="horizon-line" />
      </div>

      <section className="hero-panel" aria-label="音声入力">
        <div className="top-bar">
          <div>
            <p className="eyebrow">MORNING FLOW AI <span>v1.2</span></p>
            <h1>話して人生を整える</h1>
          </div>
          <div className="brand-mark" aria-hidden="true">
            <Sparkles size={21} />
          </div>
        </div>

        <div className="focus-area">
          <div className={`voice-stage ${isListening ? 'is-listening' : ''}`}>
            <div className="waveform" aria-hidden="true">
              {Array.from({ length: 17 }).map((_, index) => (
                <span key={index} style={{ animationDelay: `${index * 72}ms` }} />
              ))}
            </div>

            <button
              className={`mic-button ${isListening ? 'is-listening' : ''}`}
              type="button"
              onClick={isListening ? stopListening : startListening}
              disabled={!isSupported}
              aria-label={isListening ? '音声認識を停止' : '音声認識を開始'}
            >
              <span className="pulse-ring ring-one" aria-hidden="true" />
              <span className="pulse-ring ring-two" aria-hidden="true" />
              <span className="mic-glass" aria-hidden="true" />
              {isListening ? <Square size={38} fill="currentColor" /> : <Mic size={56} />}
            </button>
          </div>

          <div className="status-row" role="status" aria-live="polite">
            <span className={`status-dot ${isListening ? 'active' : ''}`} />
            {getStatusLabel(isSupported, isListening, transcript, plan)}
          </div>
        </div>

        {error && <p className="error-message">{error}</p>}

        <div className="transcript-card">
          <div className="transcript-header">
            <span>Today Capture</span>
            {interimTranscript && <span className="live-label">Listening</span>}
          </div>
          <div className={`transcript-box ${resultText ? 'has-text' : ''}`}>
            {resultText || '今日の予定、やること、目標、目的をそのまま話してください。'}
          </div>
        </div>

        {canOrganize && (
          <button
            className={`organize-button ${isOrganizing ? 'is-organizing' : ''}`}
            type="button"
            onClick={organizeMorning}
            disabled={isOrganizing}
          >
            <Brain size={21} />
            {isOrganizing ? 'AIが整理しています' : 'AI整理'}
            <Sparkles size={18} />
          </button>
        )}

        {plan && <PlanView plan={plan} />}

        <div className="action-row">
          <button className="secondary-button" type="button" onClick={resetTranscript}>
            <RefreshCw size={19} />
            やり直し
          </button>
          <button className="secondary-button sample-button" type="button" onClick={useSample}>
            サンプル
          </button>
          <button className="primary-button" type="button" disabled={!plan}>
            次へ進む
            <ArrowRight size={21} />
          </button>
        </div>
      </section>
    </main>
  );
}

function PlanView({ plan }: { plan: MorningPlan }) {
  return (
    <section className="plan-stack" aria-label="AI整理結果">
      <PlanSection icon={<Flag size={18} />} title="今日の目的">
        <p className="purpose-text">{plan.purpose}</p>
      </PlanSection>

      <PlanSection icon={<Target size={18} />} title="今日の目標">
        <ul className="clean-list">
          {plan.goals.map((goal) => (
            <li key={goal}>{goal}</li>
          ))}
        </ul>
      </PlanSection>

      <PlanSection icon={<ListChecks size={18} />} title="やることリスト">
        <div className="todo-list">
          {plan.todos.map((todo) => (
            <label key={todo} className="todo-item">
              <input type="checkbox" />
              <span>{todo}</span>
            </label>
          ))}
        </div>
      </PlanSection>

      <PlanSection icon={<Route size={18} />} title="優先順位">
        <div className="priority-grid">
          <PriorityColumn title="1. 最優先" items={plan.priorities.highest} />
          <PriorityColumn title="2. 重要" items={plan.priorities.important} />
          <PriorityColumn title="3. 時間があれば" items={plan.priorities.optional} />
        </div>
      </PlanSection>

      <PlanSection icon={<CalendarClock size={18} />} title="推奨タイムスケジュール">
        <div className="schedule-list">
          {plan.schedule.map((item) => (
            <div className="schedule-item" key={`${item.time}-${item.task}`}>
              <time>{item.time}</time>
              <span>{item.task}</span>
            </div>
          ))}
        </div>
      </PlanSection>

      <PlanSection icon={<Lightbulb size={18} />} title="AIアドバイス">
        <ul className="advice-list">
          {plan.advice.map((advice) => (
            <li key={advice}>
              <CheckCircle2 size={16} />
              <span>{advice}</span>
            </li>
          ))}
        </ul>
      </PlanSection>
    </section>
  );
}

function PlanSection({
  children,
  icon,
  title,
}: {
  children: React.ReactNode;
  icon: React.ReactNode;
  title: string;
}) {
  return (
    <article className="plan-card">
      <div className="plan-title">
        <span>{icon}</span>
        <h2>{title}</h2>
      </div>
      {children}
    </article>
  );
}

function PriorityColumn({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="priority-column">
      <h3>{title}</h3>
      {items.map((item) => (
        <span key={item}>{item}</span>
      ))}
    </div>
  );
}

function createMorningPlan(input: string): MorningPlan {
  const text = input.replace(/\s+/g, ' ').trim();
  const todos = extractTodos(text);
  const schedule = extractSchedule(text, todos);
  const goals = extractGoals(text, todos);
  const priorities = createPriorities(todos, text);

  return {
    purpose: createPurpose(text, todos),
    goals,
    todos,
    priorities,
    schedule,
    advice: createAdvice(text, schedule),
  };
}

function extractTodos(text: string) {
  const detected = knownTasks.filter((task) => text.includes(task));
  const normalized = detected.map((task) => {
    if (task === '運動' && text.includes('ジム')) return 'ジム';
    if (task === '営業' && text.includes('昼営業')) return '昼営業';
    return task;
  });

  return unique(normalized).slice(0, 8).length > 0
    ? unique(normalized).slice(0, 8)
    : ['予定の確認', '最重要タスクの実行', '生活の余白を確保'];
}

function extractGoals(text: string, todos: string[]) {
  const goals: string[] = [];
  const salesMatch = text.match(/売上[^。]*?(達成|目標)/);
  const exerciseMatch = text.match(/(\d+分)?(運動|ジム)/);

  if (salesMatch) goals.push('売上目標達成');
  if (text.includes('銀行')) goals.push('銀行手続き完了');
  if (exerciseMatch) goals.push(exerciseMatch[1] ? `${exerciseMatch[1]}運動` : '運動時間の確保');
  if (text.includes('家族')) goals.push('家族との時間を確保');

  todos.forEach((todo) => {
    if (goals.length < 4 && !goals.some((goal) => goal.includes(todo))) {
      goals.push(`${todo}を完了`);
    }
  });

  return unique(goals).slice(0, 4);
}

function extractSchedule(text: string, todos: string[]) {
  const schedule: MorningPlan['schedule'] = [];
  const rangeRegex = /(\d{1,2})時(?:から|〜|-)(\d{1,2})時(?:まで)?([^。]*)/g;
  const pointRegex = /(\d{1,2})時(?:(\d{1,2})分|半)?(?:に)?([^。]*)/g;
  let rangeMatch: RegExpExecArray | null;
  let pointMatch: RegExpExecArray | null;

  while ((rangeMatch = rangeRegex.exec(text))) {
    schedule.push({
      time: `${rangeMatch[1]}:00〜${rangeMatch[2]}:00`,
      task: findTaskName(rangeMatch[3], todos),
    });
  }

  while ((pointMatch = pointRegex.exec(text))) {
    const hour = pointMatch[1];
    const minute = pointMatch[2] ?? (pointMatch[0].includes('半') ? '30' : '00');
    const time = `${hour}:${minute.padStart(2, '0')}`;

    if (!schedule.some((item) => item.time.includes(`${hour}:`))) {
      schedule.push({
        time,
        task: findTaskName(pointMatch[3], todos),
      });
    }
  }

  if (schedule.length === 0) {
    return todos.slice(0, 5).map((todo, index) => ({
      time: ['9:00', '11:00', '14:00', '16:00', '20:00'][index] ?? '時間調整',
      task: todo,
    }));
  }

  return schedule.sort((a, b) => Number(a.time.split(':')[0]) - Number(b.time.split(':')[0])).slice(0, 7);
}

function createPriorities(todos: string[], text: string) {
  const highest = todos.filter((todo) =>
    ['銀行', '営業', '昼営業', '会議', '通院'].some((word) => todo.includes(word)),
  );
  const optional = todos.filter((todo) =>
    ['ジム', '運動', '読書', '散歩', '買い物'].some((word) => todo.includes(word)),
  );
  const important = todos.filter((todo) => !highest.includes(todo) && !optional.includes(todo));

  if (text.includes('家族') && !important.includes('家族との時間')) {
    important.push('家族との時間');
  }

  return {
    highest: highest.length ? highest : todos.slice(0, 1),
    important: important.length ? important : todos.slice(1, 3),
    optional: optional.length ? optional : todos.slice(3, 5),
  };
}

function createPurpose(text: string, todos: string[]) {
  const hasWork = ['営業', '売上', '会議', '資料', '銀行'].some((word) => text.includes(word));
  const hasLife = ['家族', '運動', 'ジム', '買い物', '掃除', '洗濯'].some((word) => text.includes(word));

  if (hasWork && hasLife) {
    return '仕事の成果を安定させながら、生活と大切な時間も整える';
  }
  if (hasWork) {
    return '重要な仕事を前に進め、今日の成果を明確に残す';
  }
  if (hasLife) {
    return '生活のリズムを整え、自分と身近な人のための余白をつくる';
  }
  return `${todos[0]}を軸に、今日を落ち着いて前へ進める`;
}

function createAdvice(text: string, schedule: MorningPlan['schedule']) {
  const advice: string[] = [];

  if (text.includes('銀行')) {
    advice.push('銀行の営業時間に注意してください。先に行く時間を固定すると安心です。');
  }
  if (schedule.length >= 4) {
    advice.push('予定が詰まりやすい日です。午後に15分でも余白時間を確保すると効率が上がります。');
  }
  if (text.includes('ジム') || text.includes('運動')) {
    advice.push('夜の運動は短めでも継続を優先すると、明日の朝が整いやすくなります。');
  }
  if (text.includes('家族')) {
    advice.push('家族との時間は後回しにせず、予定として先に置くと守りやすくなります。');
  }

  return advice.length
    ? advice.slice(0, 3)
    : ['最初に一番重い予定を片づけると、1日の判断が軽くなります。'];
}

function findTaskName(fragment: string, todos: string[]) {
  const match = todos.find((todo) => fragment.includes(todo));
  if (match) return match;
  const fallback = knownTasks.find((task) => fragment.includes(task));
  return fallback ?? (fragment.replace(/[、。]/g, '').trim() || '予定');
}

function unique(items: string[]) {
  return Array.from(new Set(items.filter(Boolean)));
}

function getStatusLabel(
  isSupported: boolean,
  isListening: boolean,
  transcript: string,
  plan: MorningPlan | null,
) {
  if (!isSupported) return 'このブラウザは音声入力に対応していません';
  if (isListening) return '音声認識中';
  if (plan) return '今日の流れを整理しました';
  if (transcript) return 'AI整理を押すと今日の計画を生成します';
  return 'タップして話しはじめる';
}

function getSpeechErrorMessage(error: string) {
  if (error === 'not-allowed' || error === 'service-not-allowed') {
    return 'マイクの使用が許可されていません。ブラウザの設定からマイクを許可してください。';
  }
  if (error === 'no-speech') {
    return '音声が聞き取れませんでした。もう一度、少し近くで話してみてください。';
  }
  if (error === 'network') {
    return '音声認識サービスに接続できませんでした。通信状況を確認してください。';
  }
  return '音声認識で問題が起きました。もう一度お試しください。';
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
